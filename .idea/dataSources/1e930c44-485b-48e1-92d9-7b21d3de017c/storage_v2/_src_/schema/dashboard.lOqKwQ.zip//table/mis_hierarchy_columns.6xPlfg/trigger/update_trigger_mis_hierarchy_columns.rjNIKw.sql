create definer = root@localhost trigger update_Trigger_MIS_HIERARCHY_COLUMNS
    after update
    on mis_hierarchy_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_HIERARCHY_COLUMNS');
END;

