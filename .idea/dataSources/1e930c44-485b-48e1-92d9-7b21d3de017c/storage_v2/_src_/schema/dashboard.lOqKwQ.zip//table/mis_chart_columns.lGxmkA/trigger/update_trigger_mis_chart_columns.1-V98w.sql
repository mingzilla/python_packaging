create definer = root@localhost trigger update_Trigger_MIS_CHART_COLUMNS
    after update
    on mis_chart_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_CHART_COLUMNS');
END;

