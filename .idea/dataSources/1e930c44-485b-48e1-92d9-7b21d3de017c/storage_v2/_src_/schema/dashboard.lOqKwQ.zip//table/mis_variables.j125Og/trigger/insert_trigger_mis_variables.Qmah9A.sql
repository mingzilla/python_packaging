create definer = root@localhost trigger insert_Trigger_MIS_VARIABLES
    after insert
    on mis_variables
    for each row
BEGIN
CALL recordTableInteraction('MIS_VARIABLES');
END;

