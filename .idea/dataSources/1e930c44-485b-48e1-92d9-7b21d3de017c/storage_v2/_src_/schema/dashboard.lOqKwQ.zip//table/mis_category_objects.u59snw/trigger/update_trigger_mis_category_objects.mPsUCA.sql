create definer = root@localhost trigger update_Trigger_MIS_CATEGORY_OBJECTS
    after update
    on mis_category_objects
    for each row
BEGIN
CALL recordTableInteraction('MIS_CATEGORY_OBJECTS');
END;

