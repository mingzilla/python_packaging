create definer = root@localhost trigger update_Trigger_MIS_LICENCES
    after update
    on mis_licences
    for each row
BEGIN
CALL recordTableInteraction('MIS_LICENCES');
END;

