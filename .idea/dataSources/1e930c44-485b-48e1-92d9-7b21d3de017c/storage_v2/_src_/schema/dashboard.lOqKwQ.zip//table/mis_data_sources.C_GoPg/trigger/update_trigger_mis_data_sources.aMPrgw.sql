create definer = root@localhost trigger update_Trigger_MIS_DATA_SOURCES
    after update
    on mis_data_sources
    for each row
BEGIN
CALL recordTableInteraction('MIS_DATA_SOURCES');
END;

