create definer = root@localhost trigger insert_Trigger_MIS_HIERARCHIES
    after insert
    on mis_hierarchies
    for each row
BEGIN
CALL recordTableInteraction('MIS_HIERARCHIES');
END;

