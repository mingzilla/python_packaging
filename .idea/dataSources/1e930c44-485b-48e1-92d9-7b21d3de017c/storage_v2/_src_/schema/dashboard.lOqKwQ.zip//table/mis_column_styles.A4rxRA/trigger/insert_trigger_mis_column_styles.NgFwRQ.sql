create definer = root@localhost trigger insert_Trigger_MIS_COLUMN_STYLES
    after insert
    on mis_column_styles
    for each row
BEGIN
CALL recordTableInteraction('MIS_COLUMN_STYLES');
END;

