create definer = root@localhost trigger insert_Trigger_MIS_TABLES
    after insert
    on mis_tables
    for each row
BEGIN
CALL recordTableInteraction('MIS_TABLES');
END;

