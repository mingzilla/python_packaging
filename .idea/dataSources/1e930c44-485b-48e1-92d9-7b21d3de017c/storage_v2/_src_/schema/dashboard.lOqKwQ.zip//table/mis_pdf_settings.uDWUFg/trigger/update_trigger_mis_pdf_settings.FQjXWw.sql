create definer = root@localhost trigger update_Trigger_MIS_PDF_SETTINGS
    after update
    on mis_pdf_settings
    for each row
BEGIN
CALL recordTableInteraction('MIS_PDF_SETTINGS');
END;

