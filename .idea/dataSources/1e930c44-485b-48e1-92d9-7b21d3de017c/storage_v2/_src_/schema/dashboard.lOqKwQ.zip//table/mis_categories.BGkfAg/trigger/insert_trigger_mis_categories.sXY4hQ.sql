create definer = root@localhost trigger insert_Trigger_MIS_CATEGORIES
    after insert
    on mis_categories
    for each row
BEGIN
CALL recordTableInteraction('MIS_CATEGORIES');
END;

