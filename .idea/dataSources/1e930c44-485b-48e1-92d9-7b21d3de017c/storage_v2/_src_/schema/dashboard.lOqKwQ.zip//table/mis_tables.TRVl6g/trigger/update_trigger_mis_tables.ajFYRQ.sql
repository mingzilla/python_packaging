create definer = root@localhost trigger update_Trigger_MIS_TABLES
    after update
    on mis_tables
    for each row
BEGIN
CALL recordTableInteraction('MIS_TABLES');
END;

