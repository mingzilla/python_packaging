create definer = root@localhost trigger delete_Trigger_MIS_COLUMNS
    after delete
    on mis_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_COLUMNS');
END;

