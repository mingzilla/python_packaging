create definer = root@localhost trigger delete_Trigger_MIS_LICENCES
    after delete
    on mis_licences
    for each row
BEGIN
CALL recordTableInteraction('MIS_LICENCES');
END;

