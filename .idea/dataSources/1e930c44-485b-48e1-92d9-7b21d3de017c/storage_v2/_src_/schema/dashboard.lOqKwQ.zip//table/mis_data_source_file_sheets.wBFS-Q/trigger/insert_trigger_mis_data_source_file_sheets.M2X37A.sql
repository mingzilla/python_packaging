create definer = root@localhost trigger insert_Trigger_MIS_DATA_SOURCE_FILE_SHEETS
    after insert
    on mis_data_source_file_sheets
    for each row
BEGIN
CALL recordTableInteraction('MIS_DATA_SOURCE_FILE_SHEETS');
END;

