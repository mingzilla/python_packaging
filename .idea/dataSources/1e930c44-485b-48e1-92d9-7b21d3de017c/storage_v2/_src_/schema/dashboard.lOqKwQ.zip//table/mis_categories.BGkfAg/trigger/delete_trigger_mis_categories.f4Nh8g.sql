create definer = root@localhost trigger delete_Trigger_MIS_CATEGORIES
    after delete
    on mis_categories
    for each row
BEGIN
CALL recordTableInteraction('MIS_CATEGORIES');
END;

