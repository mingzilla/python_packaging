create definer = root@localhost trigger insert_Trigger_MIS_DEFINED_CHARTS
    after insert
    on mis_defined_charts
    for each row
BEGIN
CALL recordTableInteraction('MIS_DEFINED_CHARTS');
END;

