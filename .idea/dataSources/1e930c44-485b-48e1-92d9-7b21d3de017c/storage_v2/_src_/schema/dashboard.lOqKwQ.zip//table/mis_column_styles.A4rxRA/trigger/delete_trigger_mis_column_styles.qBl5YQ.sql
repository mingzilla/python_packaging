create definer = root@localhost trigger delete_Trigger_MIS_COLUMN_STYLES
    after delete
    on mis_column_styles
    for each row
BEGIN
CALL recordTableInteraction('MIS_COLUMN_STYLES');
END;

