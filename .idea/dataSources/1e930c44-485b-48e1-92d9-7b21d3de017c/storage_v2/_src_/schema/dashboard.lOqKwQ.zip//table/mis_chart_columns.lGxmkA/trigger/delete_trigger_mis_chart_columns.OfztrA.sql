create definer = root@localhost trigger delete_Trigger_MIS_CHART_COLUMNS
    after delete
    on mis_chart_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_CHART_COLUMNS');
END;

