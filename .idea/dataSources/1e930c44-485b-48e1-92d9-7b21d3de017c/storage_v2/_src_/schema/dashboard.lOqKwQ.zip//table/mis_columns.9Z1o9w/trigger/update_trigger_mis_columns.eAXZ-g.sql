create definer = root@localhost trigger update_Trigger_MIS_COLUMNS
    after update
    on mis_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_COLUMNS');
END;

