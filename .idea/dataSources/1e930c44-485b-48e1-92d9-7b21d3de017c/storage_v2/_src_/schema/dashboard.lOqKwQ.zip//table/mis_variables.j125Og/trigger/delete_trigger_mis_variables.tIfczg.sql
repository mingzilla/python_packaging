create definer = root@localhost trigger delete_Trigger_MIS_VARIABLES
    after delete
    on mis_variables
    for each row
BEGIN
CALL recordTableInteraction('MIS_VARIABLES');
END;

