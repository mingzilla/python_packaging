create definer = root@localhost trigger insert_Trigger_MIS_DATA_SOURCE_FILES
    after insert
    on mis_data_source_files
    for each row
BEGIN
CALL recordTableInteraction('MIS_DATA_SOURCE_FILES');
END;

