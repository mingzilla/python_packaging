create definer = root@localhost trigger insert_Trigger_MIS_DATA_SOURCES
    after insert
    on mis_data_sources
    for each row
BEGIN
CALL recordTableInteraction('MIS_DATA_SOURCES');
END;

