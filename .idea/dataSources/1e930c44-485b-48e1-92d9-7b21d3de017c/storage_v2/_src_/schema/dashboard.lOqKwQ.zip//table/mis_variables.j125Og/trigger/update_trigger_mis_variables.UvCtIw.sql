create definer = root@localhost trigger update_Trigger_MIS_VARIABLES
    after update
    on mis_variables
    for each row
BEGIN
CALL recordTableInteraction('MIS_VARIABLES');
END;

