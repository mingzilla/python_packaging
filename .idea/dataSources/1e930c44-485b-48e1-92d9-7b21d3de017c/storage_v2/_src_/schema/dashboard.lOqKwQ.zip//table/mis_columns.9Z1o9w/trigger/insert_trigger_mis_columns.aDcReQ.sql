create definer = root@localhost trigger insert_Trigger_MIS_COLUMNS
    after insert
    on mis_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_COLUMNS');
END;

