create definer = root@localhost trigger insert_Trigger_MIS_LICENCES
    after insert
    on mis_licences
    for each row
BEGIN
CALL recordTableInteraction('MIS_LICENCES');
END;

