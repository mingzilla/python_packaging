create definer = root@localhost trigger insert_Trigger_MIS_HIERARCHY_COLUMNS
    after insert
    on mis_hierarchy_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_HIERARCHY_COLUMNS');
END;

