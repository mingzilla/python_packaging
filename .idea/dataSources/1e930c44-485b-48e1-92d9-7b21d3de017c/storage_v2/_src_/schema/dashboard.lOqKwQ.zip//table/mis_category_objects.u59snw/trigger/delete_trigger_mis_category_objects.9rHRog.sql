create definer = root@localhost trigger delete_Trigger_MIS_CATEGORY_OBJECTS
    after delete
    on mis_category_objects
    for each row
BEGIN
CALL recordTableInteraction('MIS_CATEGORY_OBJECTS');
END;

