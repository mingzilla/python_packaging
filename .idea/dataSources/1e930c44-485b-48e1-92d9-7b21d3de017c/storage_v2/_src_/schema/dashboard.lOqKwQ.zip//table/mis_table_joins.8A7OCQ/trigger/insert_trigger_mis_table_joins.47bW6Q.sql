create definer = root@localhost trigger insert_Trigger_MIS_TABLE_JOINS
    after insert
    on mis_table_joins
    for each row
BEGIN
CALL recordTableInteraction('MIS_TABLE_JOINS');
END;

