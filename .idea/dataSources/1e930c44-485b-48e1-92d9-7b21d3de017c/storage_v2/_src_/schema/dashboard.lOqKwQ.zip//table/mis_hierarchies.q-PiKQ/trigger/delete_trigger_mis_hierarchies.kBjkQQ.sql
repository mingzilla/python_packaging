create definer = root@localhost trigger delete_Trigger_MIS_HIERARCHIES
    after delete
    on mis_hierarchies
    for each row
BEGIN
CALL recordTableInteraction('MIS_HIERARCHIES');
END;

