create definer = root@localhost trigger delete_Trigger_MIS_PDF_SETTINGS
    after delete
    on mis_pdf_settings
    for each row
BEGIN
CALL recordTableInteraction('MIS_PDF_SETTINGS');
END;

