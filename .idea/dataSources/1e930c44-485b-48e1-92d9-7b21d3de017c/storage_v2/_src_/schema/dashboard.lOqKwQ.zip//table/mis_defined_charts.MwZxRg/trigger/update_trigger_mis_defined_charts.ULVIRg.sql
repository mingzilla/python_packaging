create definer = root@localhost trigger update_Trigger_MIS_DEFINED_CHARTS
    after update
    on mis_defined_charts
    for each row
BEGIN
CALL recordTableInteraction('MIS_DEFINED_CHARTS');
END;

