create definer = root@localhost trigger update_Trigger_MIS_DATA_SOURCE_FILES
    after update
    on mis_data_source_files
    for each row
BEGIN
CALL recordTableInteraction('MIS_DATA_SOURCE_FILES');
END;

