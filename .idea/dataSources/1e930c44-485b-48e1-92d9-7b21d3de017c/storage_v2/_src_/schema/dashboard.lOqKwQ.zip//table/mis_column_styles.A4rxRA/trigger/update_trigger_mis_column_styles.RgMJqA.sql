create definer = root@localhost trigger update_Trigger_MIS_COLUMN_STYLES
    after update
    on mis_column_styles
    for each row
BEGIN
CALL recordTableInteraction('MIS_COLUMN_STYLES');
END;

