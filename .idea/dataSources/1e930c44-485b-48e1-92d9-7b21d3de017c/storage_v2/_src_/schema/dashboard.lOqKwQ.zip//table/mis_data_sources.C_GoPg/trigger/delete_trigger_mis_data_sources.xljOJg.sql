create definer = root@localhost trigger delete_Trigger_MIS_DATA_SOURCES
    after delete
    on mis_data_sources
    for each row
BEGIN
CALL recordTableInteraction('MIS_DATA_SOURCES');
END;

