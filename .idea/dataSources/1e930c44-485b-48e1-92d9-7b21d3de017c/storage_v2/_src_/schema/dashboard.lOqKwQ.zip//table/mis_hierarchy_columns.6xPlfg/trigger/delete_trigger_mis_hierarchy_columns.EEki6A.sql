create definer = root@localhost trigger delete_Trigger_MIS_HIERARCHY_COLUMNS
    after delete
    on mis_hierarchy_columns
    for each row
BEGIN
CALL recordTableInteraction('MIS_HIERARCHY_COLUMNS');
END;

