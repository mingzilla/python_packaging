create definer = root@localhost trigger update_Trigger_MIS_CATEGORIES
    after update
    on mis_categories
    for each row
BEGIN
CALL recordTableInteraction('MIS_CATEGORIES');
END;

