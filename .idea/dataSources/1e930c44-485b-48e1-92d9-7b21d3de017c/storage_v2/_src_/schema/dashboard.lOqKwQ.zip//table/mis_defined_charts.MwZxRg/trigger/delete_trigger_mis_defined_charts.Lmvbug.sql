create definer = root@localhost trigger delete_Trigger_MIS_DEFINED_CHARTS
    after delete
    on mis_defined_charts
    for each row
BEGIN
CALL recordTableInteraction('MIS_DEFINED_CHARTS');
END;

