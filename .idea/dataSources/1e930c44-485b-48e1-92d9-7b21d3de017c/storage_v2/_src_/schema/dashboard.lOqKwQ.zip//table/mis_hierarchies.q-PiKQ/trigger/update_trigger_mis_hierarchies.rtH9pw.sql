create definer = root@localhost trigger update_Trigger_MIS_HIERARCHIES
    after update
    on mis_hierarchies
    for each row
BEGIN
CALL recordTableInteraction('MIS_HIERARCHIES');
END;

