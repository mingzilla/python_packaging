create definer = root@localhost trigger insert_Trigger_MIS_CATEGORY_OBJECTS
    after insert
    on mis_category_objects
    for each row
BEGIN
CALL recordTableInteraction('MIS_CATEGORY_OBJECTS');
END;

